# QuaseMario

English
> A simple game based on the "Mario" saga, using the languages: CSS, HTML, JS. 

Português
> Projeto de um jogo baseado na saga "Mario", no qual utiliza de CSS, HTML e JS em sua construção.